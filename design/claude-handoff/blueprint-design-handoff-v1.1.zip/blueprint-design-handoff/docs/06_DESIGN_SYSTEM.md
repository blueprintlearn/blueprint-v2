# Blueprint V2 — Design System

> Proposed addition to the governing docs (v1.1, approved by David Osborne on 2026-10-21). Visual and interaction rules only; the Product Constitution, Engineering Constitution, Data Model and Golden Paths take precedence.

Blueprint helps DJ-company owners build the team they need: hire, train, verify, develop, advance, without the owner being the system. The brand should feel **warm, innovative, helpful and joyful**: calm and in control for owners, exciting and rewarding for the people growing. Every screen built from this system follows the seven principles below.

## Principles

1. **Calm for owners, joyful for growth.** Owner screens lead with what needs a decision and keep everything else quiet. Celebrate only real progress: an advancement, a hire, a finished course. Owner workflows stay focused; don't fill every screen to the density of the home dashboard.
2. **Sketch to solid.** The signature motif, taken from the B mark. **Solid** = proven or done. **Hatched** = in progress. **Drafted** (construction lines overshooting the corners) = planned, not started. The motif always comes with a clear status label (StatusTag, a legend with counts, or visible stage words). It never relies on pattern or color alone, and it's never decoration.
3. **Evidence, not scores.** Show readiness through proof: verified competencies, interview quotes, observations, events. Never show an unexplained percentage or match score.
4. **Blueprint recommends, you decide.** Suggestions explain why, offer a draft (a message, a plan), and leave the click to a person. **Reversible actions offer Undo. Consequential decisions (hiring, advancement, overrides, pay) require confirmation and keep an audit trail** of who decided, when, and why.
5. **Warm, plain voice.** See Content below.
6. **One family across both themes.** Light is warm paper; dark is deep navy, designed on purpose rather than inverted. Every text pair meets WCAG AA, including small labels and secondary text on colored cards.
7. **Customer-branded where employees, trainers and applicants see it.** Owner screens are Blueprint-branded. Trainee, trainer and applicant screens keep this system's layout, type and motif but swap in the DJ company's logo and its primary color (override `brand`, and `solid` follows in light). A small "Powered by Blueprint" sits in the footer.

## Content

- **Talk like a helpful colleague.** First names, short sentences, no jargon. "Jake is ready to become an Assistant DJ," not "Advancement eligibility met."
- **"You" is the owner. "Blueprint" is the product**, in the third person: "Blueprint drafted this for you," "Blueprint suggests. You decide." Blueprint has no persona or mascot.
- **Sentence case everywhere:** headings, buttons, chips. Buttons start with a verb and name the outcome: "Send to Devon", "Plan my next hire", "Approve Jake".
- **Headlines can smile once per screen:** "You're one great DJ away from a fully staffed spring." Everything else is plain.
- **Numbers come with meaning:** "12 of 12 competencies proven", "4 days past due", "40 things Blueprint handled for you this week". Spell out small counts in prose ("Three things need you today").
- **No emoji in the interface.** Celebration comes from the confetti burst on a DecisionCard and the words.
- **Use the product's own terms:** Company Blueprint, Talent Role, Competency, Development Path, Evidence, Advancement. Nav tabs are Home, People, Development, Recruiting, Library.

## Color

- **Grounds:** `paper` is the page, `surface` is cards and panels, `surface-soft` is quiet fills inside cards.
- **Text:** `ink` for headings and primary text, `ink-2` for body, `muted` for dates and hints. All three are safe on paper, surface, surface-soft and every tint, in both themes.
- **Brand:** `brand` navy (#253860, from the B mark) anchors the system. Use one navy `brand` card per screen at most (the "handled for you" panel), with `text-on-brand`.
- **Coral** is the secondary accent and the important-action color. Use one `coral` button per view, notification pips, and the hatched highlight under a key word (`.bp-hl`). When coral is text, use `coral-text`.
- **Tints carry meaning, never decoration.** `blush` is advancement and celebration, `butter` is hiring and gentle attention, `sky` is nudges and info, `mint` is success and on track, `lavender` is training content, `danger` is errors only. Text on a tint uses `ink`, `ink-2`, `muted` or that tint's own `*-ink`. A chip on a card of the same tint sits on white (`onTint`).
- **Status is never color alone.** Every status has a word, and errors also get an icon.

## Type

- **Bricolage Grotesque** (`display`) is for the wordmark, the greeting, section headings and card titles. It's warm and slightly hand-made, which echoes the sketched B.
- **Figtree** (`body`) is for everything else.
- **Sizes:** display-xl (76) is for the one greeting per home screen; heading-l (38) for sections; heading-m (27) for card titles; body is 16. On phones, scale display-xl to 46, display-l to 33, heading-l to 29 and heading-m to 24.
- **Minimum sizes:** sentences are never smaller than 14px, and no text is smaller than 12px (stage labels, tab-bar labels). Small labels are bold.
- Both families load from Google Fonts. `components/bundle.css` imports them.

## The motif in practice

- **Solid** (`solid` fill, `.bp-solid`): verified competencies, completed journey stages, current leads in a seat map, the selected nav tab, primary buttons.
- **Hatched** (`.bp-hatch`, lines in `hatch`): the current journey stage, a person still developing toward a seat, a Company Blueprint section still in progress, a core value with limited evidence.
- **Drafted** (`.bp-drafted`, lines in `draft`, square `radius-drafted` corners): an open seat on the plan, a course on the drawing board, a section not started.
- **Shape follows status.** Finished things are rounded (`radius-lg` to `radius-2xl`), planned things are square. Pair every motif shape with words: StatusTag for swatches, the SeatMap legend with counts, JourneyTrack stage names.

## Layout and spacing

- **Desktop owner pages:** max width 1240px, 32px gutters (`space-7`), 56px above the greeting, 64px between sections (`space-10`).
- **Phones:** 16px gutters and 44px between sections. Card rows become horizontal swipe rails, and a bottom tab bar replaces the top tabs.
- **Order of the home screen:** greeting, then up to three decisions, then one forward-looking feature panel, then people, then ideas, then calendar and pipeline.
- **Cards and radius:** cards use `radius-xl` and feature panels `radius-2xl`. Buttons, chips and tabs are pills. White cards get `shadow-card`; tinted cards don't.
- **Touch targets** are at least 44px. Every interactive element shows a 2px `focus` ring at a 3px offset.

## Imagery and iconography

- **Logo:** the B mark (navy tile, sketched B in a drafting frame) beside the wordmark "Blueprint" in Bricolage Grotesque. See the Logos group. Use the mark as supplied; a cleaner redraw is planned separately.
- **Icons:** simple 24px stroke icons, rounded caps, 1.9px stroke, drawn in `ink` or `ink-2`. This system doesn't ship a full icon set yet; the bundle carries the handful it needs. For production, adopt one open-source stroke set with matching weight, such as Lucide, and keep strokes at 1.9.
- **Photography:** real photos of the DJ company's own people and events, uploaded by the customer. Never stock faces. With no photo, use an Avatar with initials on a tint.

## Accessibility

- Text meets WCAG AA (4.5:1) in both themes on every ground and tint it's documented for. Small labels on colored cards use the tint's `*-ink` or sit on a white chip.
- Interactive elements are real buttons and links. Icon-only buttons carry an `aria-label`.
- Motion is minimal: no animation is required to understand anything, and the confetti burst is static.


## Customer branding

Trainee, trainer and applicant screens wear the DJ company's brand. Owner screens stay Blueprint-branded. A company supplies three things: its **logo**, a **primary color** and, optionally, an **accent color**. Everything else (type, spacing, motif, tints, layout) stays Blueprint's, so every customer gets the same quality and the same accessibility.

### What a company can change

| Token | Default | Becomes | Rule |
| --- | --- | --- | --- |
| `brand`, `brand-deep` | Navy #253860 | Primary color | Brand panels. Text on them is white or ink, whichever reaches 4.5:1. |
| `text-on-brand`, `text-on-brand-muted` | White, #DCE4F3 | Computed | Always 4.5:1 or better on the panel. |
| `solid`, `text-on-solid` (light theme) | Navy, white | Primary, darkened if needed | Must reach 3:1 against paper and surface (it marks "proven" and "you are here") and carry white text at 4.5:1. |
| `hatch`, `draft` (light theme) | Navy at 42% and 55% | The adjusted solid at the same strengths | The motif's hatching and drafting lines follow the brand. They're always paired with a text label. |
| `coral`, `text-on-coral` | Coral, ink | Accent | Button fill. Text is ink or white, whichever reaches 4.5:1. |
| `coral-text`, `focus` | #B13E1D / #FF9C7C | Accent, darkened in light and lightened in dark | 4.5:1 on paper, surface and surface-soft in both themes. |

**Never changeable:** the status tints and their inks (`blush`, `butter`, `mint`, `sky`, `lavender`, `danger`), `ink`, `ink-2`, `muted`, `paper`, `surface`, and the dark-theme `solid` (cream). This keeps a red or green brand from ever looking like an error or a success.

### How unsafe colors are handled

1. **Validate.** Only `#RRGGBB` is accepted. Anything else is ignored and Blueprint's color is used.
2. **Adjust, keeping the hue.** If a color misses a contrast rule, its lightness moves in small steps (hue and saturation stay) until it passes. A bright yellow keeps its yellow panels with ink text, and gets a darker gold for buttons and done states.
3. **Fall back if it would change too much.** If passing needs more than a 35% lightness shift (a pale pastel, for example), that color falls back to Blueprint navy or coral.
4. **Report.** Every result comes with a report: the input, the color used, whether it was adjusted or fell back and why, and every contrast pair with its ratio. The brand settings screen shows this to the owner in plain words: "We darkened your color slightly so buttons stay readable."
5. **Dark theme.** Brand panels use a version of the primary that holds white text and stays visibly distinct from the dark page. Dark `solid`, `hatch` and `draft` stay Blueprint cream for every customer.

### Logo

Customers upload PNG, JPG or SVG. It shows at 38px tall in the top bar, on `paper`, with no recoloring. If there's no logo, the company name appears in `wordmark` style. "Powered by Blueprint" (`small`, `muted`) sits in the footer of every customer-branded screen, never in the top bar.

### In code

`lib/brand/tenant-theme.ts` implements this exactly: `computeTenantTheme({ primary, accent })` returns the overrides and the report, and `tenantThemeCss()` writes them as CSS scoped to `[data-tenant-brand]`. Unit tests cover the defaults, invalid input, adjustment, fallback, reserved tokens, and 600 random colors with zero failing contrast pairs.
