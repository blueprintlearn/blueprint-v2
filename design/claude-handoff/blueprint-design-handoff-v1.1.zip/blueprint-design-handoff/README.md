# Blueprint V2 — Design System Developer Handoff (v1.1)

**Status:** approved visual foundation, ready for review. **Nothing here has been applied to the `blueprint-v2` repository.** Integrate it through the small work orders below, each reviewed on its own, following the Engineering Constitution.

- **Source of truth for visuals:** the Blueprint V2 design system in Claude (live component previews), mirrored in `docs/06_DESIGN_SYSTEM.md`.
- **Source of truth for values:** `design-tokens/tokens.json`. `styles/blueprint/tokens.css` is generated from it.
- **Stack:** Next.js 16 App Router, React 19, TypeScript strict, Tailwind v4. It uses no new runtime dependencies.

---

## What's in the package

Paths mirror the repo, so each file drops in where it will live.

```
design-tokens/tokens.json              Single source of truth: colors (light + dark), type, spacing, radius, shadow
scripts/build-blueprint-tokens.mjs     tokens.json → styles/blueprint/tokens.css  (--check mode for CI)
styles/blueprint/tokens.css            GENERATED. CSS custom properties, light/dark, system-preference fallback, .bp-type-* classes
styles/blueprint/components.css        Component styles (.bp-*). Uses only var(--token)
styles/blueprint/tailwind-theme.css    Tailwind v4 @theme mapping: bg-paper, text-ink, bg-solid, rounded-bp-xl, shadow-bp-card, font-heading …
app/globals.css                        REPLACES current file. Imports Tailwind + the three files above, wires fonts
app/layout.tsx                         REPLACES current file. Loads fonts; body becomes .bp-root. Metadata unchanged
app/fonts/*.woff2 + LICENSE-*.txt      Self-hosted Bricolage Grotesque + Figtree (SIL OFL 1.1), Latin subset
lib/fonts.ts                           next/font/local setup (no Google Fonts fetch at build time)
lib/brand/tenant-theme.ts              Customer-brand color overrides: contrast checks, adjustment, fallbacks, report
components/blueprint/*.tsx             12 components + Icon + helpers, barrel at components/blueprint/index.ts
components/blueprint/examples/OwnerHomeExample.tsx   Reference composition of the approved B4 home (not a route)
public/brand/blueprint-b-mark.jpg      The B mark (1080×1080 raster; vector originals still to come)
tests/unit/tenant-theme.test.ts        10 tests, incl. 600 random brand colors with zero failing contrast pairs
tests/unit/blueprint-components.test.ts 10 render/a11y tests for every component
docs/06_DESIGN_SYSTEM.md               Brand guide + rules (proposed addition to the governing docs)
docs/screenshots/                      Rendered from a production build of a scratch copy of the repo
```

### Components

| Component | Client? | Purpose |
| --- | --- | --- |
| `Button` | server-safe | primary (solid), coral (one per view), soft, plain |
| `Chip` | server-safe | Short label naming what a card or row is about |
| `StatusTag` | server-safe | The sketch-to-solid motif swatch, always with words |
| `Card` | server-safe | surface, tint (meaningful), or brand container |
| `DecisionCard` | `"use client"` | A human decision: reversible = Undo; `consequential` = confirm + "Recorded", async-safe with error state |
| `Avatar` | server-safe | Rounded-square photo or initials on a tint |
| `JourneyTrack` | server-safe | Learn · Practice · Prove · Advance, sketch-to-solid, with visible stage words |
| `SeatMap` | server-safe | Seats needed: proven / in progress / planned, legend with counts |
| `MessageBubble` | server-safe | A drafted message (always paired with Edit + Send) |
| `TopNav` | `"use client"` | Logo, wordmark, workspace, tabs (`next/link`, active via `usePathname`) |
| `BottomTabBar` | `"use client"` | Phone navigation, same destinations, badges, safe-area aware |
| `TenantBrandScope` | server | Applies a company's safe color overrides to a subtree |

Server-safe components work in Server Components. Pass event handlers only from Client Components.

---

## Integration plan (work orders for Charlie)

Each order is one bounded slice. Don't combine them.

### WO-1 · Design foundations: tokens, fonts, global styles · **GREEN**
**Change:** Add `design-tokens/`, `scripts/build-blueprint-tokens.mjs`, `styles/blueprint/*`, `app/fonts/*`, `lib/fonts.ts` and `public/brand/blueprint-b-mark.jpg`. Replace `app/globals.css` and `app/layout.tsx`. Optionally add `"tokens:build": "node scripts/build-blueprint-tokens.mjs"` to `package.json`.
**Why:** It puts the approved brand into the real app with no behavior change.
**What could break:** Only the look of the existing Stage 1 screens: Geist and Arial become Figtree, and the background becomes warm paper. The Tailwind classes they use (`border`, `px-3`, etc.) still work.
**Tests:** `pnpm typecheck`, `pnpm lint`, `pnpm test`, `pnpm build`, `node scripts/build-blueprint-tokens.mjs --check`.
**Manual check:** Open sign-in, sign-up and home on staging in light and dark (system setting). Text should be readable and the fonts should be Figtree and Bricolage.

### WO-2 · Component library · **GREEN**
**Change:** Add `components/blueprint/**` and `tests/unit/blueprint-components.test.ts`. No route uses them yet.
**Tests:** As in WO-1. The new tests cover rendering plus the accessibility promises: words beside every motif swatch, `aria-current` on navigation, and a "Recorded" state on consequential decisions.
**Manual check:** Optionally mount `OwnerHomeExample` on a temporary, non-production preview route, then remove it before merge, or keep it behind staging only.

### WO-3 · Customer-brand color engine · **YELLOW** (logic, no data yet)
**Change:** Add `lib/brand/tenant-theme.ts` and `tests/unit/tenant-theme.test.ts`. `TenantBrandScope` ships in WO-2 but stays unused.
**Not included:** storing a company's colors and logo. That needs a migration on `companies` (the Data Model lists "branding"), RLS, and an owner-only settings screen. It's a separate, approved product slice; treat its migration as **RED**.
**Tests:** `pnpm test`. The property test runs 600 random colors.

### WO-4 and later · Apply the system to screens
After each screen design is approved (Company Blueprint onboarding is next), restyle that screen with these components in its own slice.

---

## Using it

```tsx
import { Button, Card, DecisionCard, JourneyTrack, StatusTag } from "@/components/blueprint"

<Card tone="surface" title="Luis Ortega">
  <p className="bp-card__body">Becoming a Wedding Lead</p>
  <JourneyTrack current={2} />
</Card>
```

- **Tailwind:** `bg-paper text-ink`, `bg-surface`, `text-ink-2`, `text-muted`, `bg-solid text-on-solid`, `text-coral-text`, `bg-mint text-mint-ink`, `rounded-bp-xl`, `shadow-bp-card`, `font-heading`. `font-sans` is Figtree.
- **Type styles:** use the `.bp-type-*` classes: `display-xl`, `display-l`, `heading-l`, `heading-m`, `heading-s`, `wordmark`, `lead`, `body`, `body-strong`, `small`, `label`, `caption`. Phone sizes are in the design doc.
- **The motif:** `.bp-solid`, `.bp-hatch`, `.bp-drafted` and `.bp-hl` (the hatched highlight under a key word). Always put words next to them.
- **Theme:** with no attribute, it follows the system setting. Set `data-theme="light"` or `data-theme="dark"` on `<html>` to force one. A theme toggle (and saving the choice) is a separate small slice.
- **Phones:** render `<BottomTabBar items={…} className="bp-mobile-only" />` as the last child of the page column. Don't wrap it, or `position: sticky` can't pin it. `TopNav` tabs hide below 760px automatically. `.bp-mobile-only` and `.bp-desktop-only` are available.
- **Decisions:** for consequential actions (advancement, hire or reject, overrides, pay), pass `consequential` and have `onDecide` call a server action that writes the decision **and the audit entry** (who, when, what, any override reason). If it throws, the card says nothing changed and stays open. Never mark a consequential decision reversible.
- **Customer branding:** on trainee, trainer and applicant layouts:
  ```tsx
  <TenantBrandScope brand={{ primary: company.brandPrimary, accent: company.brandAccent }}>{children}</TenantBrandScope>
  ```
  Colors must come from the company's tenant-isolated record, saved by an owner. `computeTenantTheme()` also returns a `report` to show on the brand-settings screen ("We darkened your color slightly so buttons stay readable").

### Rules developers must keep

1. Text meets WCAG AA (4.5:1) in both themes. Use only the text/background pairs listed in each token's usage note.
2. The motif is never pattern- or color-only: always add a label, legend or visible stage words.
3. No unexplained scores. Show evidence (verified counts, quotes, observations).
4. Reversible actions offer Undo. Consequential decisions confirm and keep an audit trail.
5. Status tints (`blush`, `butter`, `mint`, `sky`, `lavender`, `danger`) are never tenant-overridable and never decorative.
6. Touch targets are at least 44px. Every interactive element is a real `<button>` or `<a>` with a visible `focus` ring.
7. Don't hard-code a hex value in components. Add or change a token in `tokens.json` and regenerate.

---

## What was verified, and how

All of this ran on a throwaway copy of `blueprint-v2` (commit `090bbf1`) with the handoff files added. The real repository was not modified.

| Check | Result |
| --- | --- |
| `pnpm typecheck` (tsc strict) | Pass |
| `pnpm lint` (eslint-config-next) | Pass, no warnings |
| `vitest run tests/unit` | 53 / 53 pass (33 existing + 20 new) |
| `pnpm build` (Next.js production) | Pass; existing routes unchanged |
| `build-blueprint-tokens.mjs --check` | tokens.css in sync with tokens.json |
| Visual check (Chromium, production build) | Light, dark, phone with tab bar, customer-branded (teal + orange). See `docs/screenshots/` |
| Contrast | Every documented text pair is at least 4.5:1 in both themes; brand engine verified on 600 random colors |

**Not verified here:** the RLS, integration and E2E suites (they need local Supabase via Docker) and real devices. They're unaffected by these files, but CI will run them.

## Known limits and follow-ups

- The **logo** is a 1080px raster. Add the SVG originals when available; a redraw is planned separately.
- **Icons:** only the 12 that v1 needs. For new icons, adopt Lucide (MIT) at stroke 1.9.
- **Fonts** are the Latin subset only, which covers English and Spanish accents. Add latin-ext files if needed.
- **`Avatar`** uses a plain `<img>` for customer-uploaded photos (one documented lint exception). Switch to `next/image` once tenant storage domains are fixed.
- The design system's in-Claude previews run React 18. The app runs React 19. The component APIs are identical.
